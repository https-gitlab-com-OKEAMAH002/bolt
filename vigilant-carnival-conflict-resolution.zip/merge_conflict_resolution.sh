
#!/bin/bash

# Define the base and head branches
BASE_BRANCH="main"
HEAD_BRANCH="feature-branch"

# Checkout the base branch
git checkout $BASE_BRANCH
git pull origin $BASE_BRANCH

# Merge the head branch into base
git merge $HEAD_BRANCH

# Check for conflicts
CONFLICTS=$(git diff --name-only --diff-filter=U)
if [ -z "$CONFLICTS" ]; then
  echo "No conflicts detected. Merging branches."
else
  echo "Conflicts detected in the following files:"
  echo "$CONFLICTS"
  echo "Resolve the conflicts manually and then run:"
  echo "  git add <file>"
  echo "  git commit -m 'Resolved conflicts'"
  echo "  git push origin $HEAD_BRANCH"
fi
